<img src="https://capsule-render.vercel.app/api?type=waving&height=200&color=gradient&customColorList=6,11,20,29&text=Grayson%20cantu&fontSize=48&fontColor=fff&animation=twinkling&fontAlignY=35&desc=Technical%20writer&descSize=18&descAlignY=55&textBg=false"/>

<p align="center">
  <a href="https://komarev.com/ghpvc/?username=Graysoncantu">
    <img src="https://komarev.com/ghpvc/?username=Graysoncantu&label=Profile%20views&color=00FFFF&style=flat-square" alt="Graysoncantu's profile views" />
  </a>
</p>

<img src="https://i.pinimg.com/originals/64/72/36/647236fc1c3aec4ac575c4ed5a8ca524.gif" alt="Banner" width="100%" />

## 📊 GitHub Stats & Trophies
<p align="center">
  <a href="https://github.com/Graysoncantu">
    <img height="180em" src="https://github-readme-stats-eight-theta.vercel.app/api?username=Graysoncantu&cache_seconds=7200&layout=compact&theme=dark&border_radius=10" alt="Graysoncantu's GitHub Stats" />
  </a>
  <img src="https://streak-stats.demolab.com/?user=Graysoncantu&theme=dark&hide_border=true&cache_seconds=86400" alt="Graysoncantu's GitHub Streak" width="49%" />
</p>
<p align="center">
  <img src="https://trophy.ryglcloud.net/?username=Graysoncantu&theme=dark&no-frame=true&no-bg=true&margin-w=4&cache_seconds=86400" alt="Grayson cantu's GitHub Trophies" />
</p>
<p align="center">
  <img height="280em" src="https://github-readme-activity-graph.vercel.app/graph?username=Graysoncantu&theme=dark&radius=10" alt="Graysoncantu's Activity Graph" />
</p>
<div align="center">
  <img src="profile-3d-city.svg" alt="3D City" width="100%" />
</div>


## 🛠️ Languages & Tools

<h3 align="center">Programming Languages</h3>
<p align="center">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="JavaScript" width="40" />&nbsp;&nbsp;
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-original.svg" alt="TypeScript" width="40" />&nbsp;&nbsp;
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="Python" width="40" />&nbsp;&nbsp;
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg" alt="Java" width="40" />&nbsp;&nbsp;
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/cplusplus/cplusplus-original.svg" alt="C++" width="40" />&nbsp;&nbsp;
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/csharp/csharp-original.svg" alt="C#" width="40" />

</p>

<h3 align="center">Frontend</h3>
<p align="center">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg" alt="React" width="40" />&nbsp;&nbsp;
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg" alt="HTML5" width="40" />&nbsp;&nbsp;
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg" alt="CSS3" width="40" />

</p>

<h3 align="center">DevOps & Cloud</h3>
<p align="center">
  <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/docker/docker-original.svg" alt="Docker" width="40" />&nbsp;&nbsp;
  <img src="https://www.vectorlogo.zone/logos/google_cloud/google_cloud-icon.svg" alt="Google Cloud" width="40" />

</p>

<h3 align="center">Tools</h3>
<p align="center">
  <img src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg" alt="Git" width="40" />

</p>

<p align="center">
  <a href="https://github.com/Graysoncantu">
    <img height="180em" src="https://github-readme-stats-eight-theta.vercel.app/api/top-langs/?username=Graysoncantu&langs_count=8&layout=compact&theme=dark&border_radius=10" alt="Top Languages" />
  </a>
</p>

![Top language](https://stats.pphat.top/languages?username=Graysoncantu)
<br/>

<p align="center"><a href="https://www.buymeacoffee.com/chamidudili" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: 41px !important;width: 174px !important;box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;-webkit-box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;" ></a></p>

<div align="center">
  <img src="https://user-images.githubusercontent.com/74038190/212284115-f47cd8ff-2ffb-4b04-b5bf-4d1c14c0247f.gif" alt="Bottom Line" width="100%" />
</div>

